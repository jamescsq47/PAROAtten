# Inficom
A backup repo containing Infinigence's kernel library.
