# please use a new virtual env
pip3 install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
pip install -r requirements.txt
pip install inficom-0.0.1-cp310-cp310-linux_x86_64.whl